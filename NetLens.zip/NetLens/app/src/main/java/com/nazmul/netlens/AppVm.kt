package com.nazmul.netlens

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.location.LocationManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nazmul.netlens.data.Isp
import com.nazmul.netlens.data.SpeedResult
import com.nazmul.netlens.data.Store
import com.nazmul.netlens.net.ApResult
import com.nazmul.netlens.net.AppUsage
import com.nazmul.netlens.net.Diagnostics
import com.nazmul.netlens.net.DnsResult
import com.nazmul.netlens.net.HealthCheck
import com.nazmul.netlens.net.HealthItem
import com.nazmul.netlens.net.IspLookup
import com.nazmul.netlens.net.PublicInfo
import com.nazmul.netlens.net.SpeedTest
import com.nazmul.netlens.net.UsageTools
import com.nazmul.netlens.net.WifiState
import com.nazmul.netlens.net.WifiTools
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class AppVm(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>().applicationContext
    private val store = Store(app)

    // ---------- Speed test ----------
    var running by mutableStateOf(false)
        private set
    var phase by mutableStateOf("Ready")
        private set
    var live by mutableDoubleStateOf(0.0)
        private set
    var down by mutableDoubleStateOf(0.0)
        private set
    var up by mutableDoubleStateOf(0.0)
        private set
    var ping by mutableDoubleStateOf(0.0)
        private set
    var jitter by mutableDoubleStateOf(0.0)
        private set
    var history by mutableStateOf(store.history())
        private set
    var pubInfo by mutableStateOf<PublicInfo?>(null)
        private set
    private var job: Job? = null

    fun loadPublicInfo(force: Boolean = false) {
        if (pubInfo != null && !force) return
        viewModelScope.launch { IspLookup.lookup()?.let { pubInfo = it } }
    }

    fun startSpeedTest() {
        if (running) return
        running = true
        down = 0.0; up = 0.0; ping = 0.0; jitter = 0.0; live = 0.0
        job = viewModelScope.launch {
            try {
                phase = "Finding your ISP…"
                if (pubInfo == null) pubInfo = IspLookup.lookup()
                phase = "Measuring latency…"
                val (p, j) = SpeedTest.latency()
                ping = p
                jitter = j
                phase = "Download"
                down = SpeedTest.download { live = it }
                phase = "Upload"
                live = 0.0
                up = SpeedTest.upload { live = it }
                live = down
                phase = if (down > 0) "Done" else "No connection"
                if (down > 0) {
                    store.addHistory(
                        SpeedResult(System.currentTimeMillis(), down, up, ping, jitter, pubInfo?.isp.orEmpty())
                    )
                    history = store.history()
                }
            } catch (e: CancellationException) {
                phase = "Stopped"
                throw e
            } catch (e: Exception) {
                phase = "Failed: ${e.message}"
            } finally {
                running = false
            }
        }
    }

    fun stopSpeedTest() {
        job?.cancel()
    }

    fun clearHistory() {
        store.clearHistory()
        history = emptyList()
    }

    // ---------- Health check ----------
    var health by mutableStateOf<List<HealthItem>>(emptyList())
        private set
    var healthRunning by mutableStateOf(false)
        private set

    fun runHealth() {
        if (healthRunning) return
        viewModelScope.launch {
            healthRunning = true
            try {
                health = HealthCheck.run(ctx)
            } finally {
                healthRunning = false
            }
        }
    }

    // ---------- Wi-Fi ----------
    var wifiInfo by mutableStateOf<WifiState?>(null)
        private set
    var aps by mutableStateOf<List<ApResult>>(emptyList())
        private set
    var scanning by mutableStateOf(false)
        private set

    fun scanWifi() {
        if (scanning) return
        viewModelScope.launch {
            scanning = true
            try {
                wifiInfo = WifiTools.current(ctx)
                aps = WifiTools.scan(ctx)
            } finally {
                scanning = false
            }
        }
    }

    // ---------- Tools ----------
    var toolOut by mutableStateOf("")
        private set
    var toolBusy by mutableStateOf(false)
        private set

    private fun runTool(block: suspend () -> Unit) {
        if (toolBusy) return
        toolBusy = true
        toolOut = ""
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toolOut += "\nError: ${e.message}"
            } finally {
                toolBusy = false
            }
        }
    }

    fun runPing(host: String) = runTool {
        toolOut = "Pinging $host …\n"
        toolOut = Diagnostics.pingText(host, 4)
    }

    fun runTraceroute(host: String) = runTool {
        toolOut = "Traceroute to $host\nhop  address            ~time\n"
        var n = 0
        Diagnostics.traceroute(host).collect { h ->
            n++
            toolOut += "${h.ttl.toString().padEnd(5)}${(h.ip ?: "*").padEnd(19)}${h.ms} ms\n"
        }
        toolOut += if (n == 0) "Could not resolve host or run probes.\n" else "Done. (time per hop is approximate)\n"
    }

    fun runDns(host: String) = runTool {
        toolOut = Diagnostics.dnsLookup(host)
    }

    var dnsResults by mutableStateOf<List<DnsResult>>(emptyList())
        private set
    var dnsBusy by mutableStateOf(false)
        private set

    fun runDnsBench() {
        if (dnsBusy) return
        viewModelScope.launch {
            dnsBusy = true
            try {
                val extra = Diagnostics.systemDns(ctx).map { "Your network DNS" to it }
                dnsResults = Diagnostics.dnsBench(extra)
            } finally {
                dnsBusy = false
            }
        }
    }

    // ---------- Data usage ----------
    var usageAccess by mutableStateOf(false)
        private set
    var usage by mutableStateOf<List<AppUsage>>(emptyList())
        private set
    var usageDays by mutableIntStateOf(1)
        private set
    var usageLoading by mutableStateOf(false)
        private set

    fun refreshUsage() {
        viewModelScope.launch {
            usageAccess = UsageTools.hasAccess(ctx)
            if (usageAccess) {
                usageLoading = true
                try {
                    usage = UsageTools.query(ctx, usageDays)
                } finally {
                    usageLoading = false
                }
            }
        }
    }

    fun setUsageDays(d: Int) {
        usageDays = d
        refreshUsage()
    }

    // ---------- ISP directory ----------
    var isps by mutableStateOf(store.isps())
        private set
    var myLoc by mutableStateOf<Pair<Double, Double>?>(null)
        private set

    fun saveIsp(isp: Isp) {
        store.saveIsp(isp)
        isps = store.isps()
    }

    fun deleteIsp(id: String) {
        store.deleteIsp(id)
        isps = store.isps()
    }

    @SuppressLint("MissingPermission")
    fun locate() {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        ).mapNotNull {
            try {
                lm.getLastKnownLocation(it)
            } catch (e: Exception) {
                null
            }
        }.maxByOrNull { it.time }
        if (loc != null) myLoc = loc.latitude to loc.longitude
    }
}
