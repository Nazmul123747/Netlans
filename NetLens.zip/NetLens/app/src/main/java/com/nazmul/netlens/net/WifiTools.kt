package com.nazmul.netlens.net

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.pow

data class WifiState(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val linkMbps: Int,
    val freq: Int,
    val channel: Int,
    val band: String,
    val distanceM: Double
)

data class ApResult(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val freq: Int,
    val channel: Int,
    val band: String,
    val security: String
)

object WifiTools {
    fun channelOf(f: Int): Int = when {
        f == 2484 -> 14
        f in 2412..2472 -> (f - 2407) / 5
        f in 5170..5895 -> (f - 5000) / 5
        f in 5955..7115 -> (f - 5950) / 5
        else -> -1
    }

    fun bandOf(f: Int): String = when {
        f < 3000 -> "2.4 GHz"
        f < 5900 -> "5 GHz"
        else -> "6 GHz"
    }

    /** Free-space path-loss estimate. Walls and antennas make this very rough. */
    fun distanceM(rssi: Int, freq: Int): Double =
        10.0.pow((27.55 - 20 * log10(freq.toDouble()) + abs(rssi)) / 20.0)

    private fun wm(ctx: Context) =
        ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    @Suppress("DEPRECATION")
    fun current(ctx: Context): WifiState? {
        return try {
            val info = wm(ctx).connectionInfo ?: return null
            if (info.bssid == null || info.frequency <= 0) return null
            val raw = info.ssid?.trim('"') ?: ""
            val ssid = if (raw.isEmpty() || raw == "<unknown ssid>") "(hidden or location off)" else raw
            WifiState(
                ssid = ssid,
                bssid = info.bssid,
                rssi = info.rssi,
                linkMbps = info.linkSpeed,
                freq = info.frequency,
                channel = channelOf(info.frequency),
                band = bandOf(info.frequency),
                distanceM = distanceM(info.rssi, info.frequency)
            )
        } catch (e: SecurityException) {
            null
        }
    }

    private fun securityOf(cap: String): String = when {
        cap.contains("SAE") || cap.contains("WPA3") -> "WPA3"
        cap.contains("WPA2") -> "WPA2"
        cap.contains("WPA") -> "WPA"
        cap.contains("WEP") -> "WEP"
        else -> "Open"
    }

    @Suppress("DEPRECATION")
    suspend fun scan(ctx: Context): List<ApResult> {
        val w = wm(ctx)
        try {
            w.startScan() // throttled by Android; we fall back to the last results
        } catch (e: Exception) {
        }
        delay(2500)
        val results = try {
            w.scanResults
        } catch (e: SecurityException) {
            emptyList()
        }
        return results.map { r ->
            ApResult(
                ssid = r.SSID.orEmpty(),
                bssid = r.BSSID.orEmpty(),
                rssi = r.level,
                freq = r.frequency,
                channel = channelOf(r.frequency),
                band = bandOf(r.frequency),
                security = securityOf(r.capabilities.orEmpty())
            )
        }.sortedByDescending { it.rssi }
    }

    /** Congestion score for 2.4 GHz channels 1..13: nearby networks (±4 channels) weighted by signal. */
    fun congestion24(aps: List<ApResult>): List<Float> = (1..13).map { ch ->
        aps.filter { it.band == "2.4 GHz" && abs(it.channel - ch) <= 4 }
            .sumOf { ((it.rssi + 100).coerceIn(0, 60) / 60.0) + 0.2 }
            .toFloat()
    }
}
