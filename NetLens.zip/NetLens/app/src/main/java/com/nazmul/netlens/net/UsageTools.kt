package com.nazmul.netlens.net

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Process
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppUsage(val label: String, val wifi: Long, val mobile: Long) {
    val total: Long get() = wifi + mobile
}

/** Per-app data usage from Android's NetworkStatsManager (needs "Usage access" permission). */
object UsageTools {
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    suspend fun query(ctx: Context, days: Int): List<AppUsage> = withContext(Dispatchers.IO) {
        val nsm = ctx.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val end = System.currentTimeMillis()
        val start = end - days * 86_400_000L
        val wifi = HashMap<Int, Long>()
        val mobile = HashMap<Int, Long>()

        fun collect(type: Int, into: HashMap<Int, Long>) {
            try {
                val st = nsm.querySummary(type, null, start, end)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    into[b.uid] = (into[b.uid] ?: 0L) + b.rxBytes + b.txBytes
                }
                st.close()
            } catch (e: Exception) {
                // permission revoked or no data for this transport
            }
        }
        collect(ConnectivityManager.TYPE_WIFI, wifi)
        collect(ConnectivityManager.TYPE_MOBILE, mobile)

        val pm = ctx.packageManager
        (wifi.keys + mobile.keys)
            .map { uid -> AppUsage(labelFor(pm, uid), wifi[uid] ?: 0L, mobile[uid] ?: 0L) }
            .filter { it.total > 0 }
            .sortedByDescending { it.total }
            .take(50)
    }

    @Suppress("DEPRECATION")
    private fun labelFor(pm: PackageManager, uid: Int): String {
        if (uid == NetworkStats.Bucket.UID_REMOVED) return "Removed apps"
        if (uid == NetworkStats.Bucket.UID_TETHERING) return "Hotspot / tethering"
        if (uid == Process.SYSTEM_UID) return "Android system"
        val pkgs = pm.getPackagesForUid(uid) ?: return "uid $uid"
        return try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkgs[0], 0)).toString()
        } catch (e: Exception) {
            pkgs[0]
        }
    }
}
