package com.nazmul.netlens.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.nazmul.netlens.fmt1
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.URL

/** level: 0 = good, 1 = so-so, 2 = bad */
data class HealthItem(val label: String, val value: String, val level: Int)

object HealthCheck {
    suspend fun run(ctx: Context): List<HealthItem> = withContext(Dispatchers.IO) {
        val out = mutableListOf<HealthItem>()
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork
        val caps = if (net != null) cm.getNetworkCapabilities(net) else null
        if (net == null || caps == null) {
            out += HealthItem("Connection", "No active network", 2)
            return@withContext out
        }

        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }
        out += HealthItem("Connection", type, 0)

        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        out += HealthItem("Internet validated", if (validated) "Yes" else "No", if (validated) 0 else 2)

        out += HealthItem(
            "Link speed (reported by Android)",
            "${caps.linkDownstreamBandwidthKbps / 1000} down / ${caps.linkUpstreamBandwidthKbps / 1000} up Mbps",
            0
        )

        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            WifiTools.current(ctx)?.let { w ->
                val lvl = if (w.rssi >= -60) 0 else if (w.rssi >= -72) 1 else 2
                out += HealthItem("Wi-Fi signal", "${w.rssi} dBm (${w.band}, ch ${w.channel})", lvl)
            }
        }

        val lp = cm.getLinkProperties(net)
        val gw = lp?.routes
            ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway?.hostAddress
        if (gw != null) {
            val st = Diagnostics.pingStats(gw, 3)
            val avg = st.avgMs
            val lvl = when {
                avg == null -> 2
                avg < 10 -> 0
                avg < 30 -> 1
                else -> 2
            }
            out += HealthItem(
                "Gateway $gw",
                if (avg == null) "no reply" else "${fmt1(avg)} ms" + (st.lossPct?.let { ", $it% loss" } ?: ""),
                lvl
            )
        }

        val dnsMs = Diagnostics.lookupMs("example.com")
        out += HealthItem(
            "DNS lookup",
            if (dnsMs < 0) "failed" else "$dnsMs ms",
            when {
                dnsMs < 0 -> 2
                dnsMs < 60 -> 0
                dnsMs < 150 -> 1
                else -> 2
            }
        )

        val t0 = System.nanoTime()
        val code = try {
            val c = URL("https://connectivitycheck.gstatic.com/generate_204").openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            val rc = c.responseCode
            c.disconnect()
            rc
        } catch (e: Exception) {
            -1
        }
        val ms = (System.nanoTime() - t0) / 1_000_000
        out += HealthItem(
            "Internet reachability",
            if (code == 204) "$ms ms" else "unreachable",
            when {
                code != 204 -> 2
                ms < 150 -> 0
                ms < 400 -> 1
                else -> 2
            }
        )
        out
    }
}
