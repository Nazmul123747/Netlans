package com.nazmul.netlens.net

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress

data class Hop(val ttl: Int, val ip: String?, val ms: Long)
data class DnsResult(val label: String, val server: String, val ms: Long) // ms < 0 = failed
data class PingStats(val avgMs: Double?, val lossPct: Int?)

object Diagnostics {
    private const val PING = "/system/bin/ping"
    private val hostRe = Regex("^[A-Za-z0-9][A-Za-z0-9.\\-]*$")
    private val hopIpRe = Regex("(?i)from\\s+(\\d{1,3}(?:\\.\\d{1,3}){3})")

    /** Hostname / IPv4 only, never starting with '-', so it can't be read as a ping option. */
    fun validHost(h: String): Boolean = h.length in 1..253 && hostRe.matches(h)

    suspend fun pingText(host: String, count: Int = 4): String = withContext(Dispatchers.IO) {
        if (!validHost(host)) return@withContext "Invalid host name"
        try {
            val p = ProcessBuilder(PING, "-c", "$count", "-W", "2", host)
                .redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim().ifEmpty { "No output from ping" }
        } catch (e: Exception) {
            "Ping failed: ${e.message}"
        }
    }

    suspend fun pingStats(host: String, count: Int = 3): PingStats = withContext(Dispatchers.IO) {
        val out = pingText(host, count)
        val avg = Regex("=\\s*[\\d.]+/([\\d.]+)/[\\d.]+").find(out)?.groupValues?.get(1)?.toDoubleOrNull()
        val loss = Regex("(\\d+)%\\s*packet loss").find(out)?.groupValues?.get(1)?.toIntOrNull()
        PingStats(avg, loss)
    }

    /**
     * Traceroute built on `ping -t <ttl>`. Android ships no traceroute binary, so the time shown
     * per hop is the wall-clock time of the probe (approximate, includes process start-up).
     */
    fun traceroute(host: String, maxHops: Int = 20): Flow<Hop> = flow {
        if (!validHost(host)) return@flow
        val target = try {
            InetAddress.getAllByName(host).firstOrNull { it is Inet4Address }?.hostAddress
        } catch (e: Exception) {
            null
        }
        if (target == null) return@flow
        for (ttl in 1..maxHops) {
            val t0 = System.nanoTime()
            val out = try {
                val p = ProcessBuilder(PING, "-c", "1", "-W", "2", "-t", "$ttl", target)
                    .redirectErrorStream(true).start()
                val s = p.inputStream.bufferedReader().readText()
                p.waitFor()
                s
            } catch (e: Exception) {
                ""
            }
            val ms = (System.nanoTime() - t0) / 1_000_000
            val ip = hopIpRe.find(out)?.groupValues?.get(1)
            emit(Hop(ttl, ip, ms))
            if (out.contains("bytes from")) break // reached the destination
        }
    }.flowOn(Dispatchers.IO)

    suspend fun dnsLookup(host: String): String = withContext(Dispatchers.IO) {
        if (!validHost(host)) return@withContext "Invalid host name"
        val t0 = System.nanoTime()
        try {
            val all = InetAddress.getAllByName(host)
            val ms = (System.nanoTime() - t0) / 1_000_000
            "Resolved in $ms ms\n" + all.joinToString("\n") { it.hostAddress ?: "" }
        } catch (e: Exception) {
            "Lookup failed: ${e.message}"
        }
    }

    /** System resolver time in ms, or -1 on failure. */
    suspend fun lookupMs(host: String): Long = withContext(Dispatchers.IO) {
        val t0 = System.nanoTime()
        try {
            InetAddress.getAllByName(host)
            (System.nanoTime() - t0) / 1_000_000
        } catch (e: Exception) {
            -1L
        }
    }

    fun systemDns(ctx: Context): List<String> {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return emptyList()
        return cm.getLinkProperties(net)?.dnsServers
            ?.mapNotNull { it.hostAddress }
            ?.filter { !it.contains(':') } // IPv4 only
            ?: emptyList()
    }

    private fun buildQuery(name: String): ByteArray {
        val out = ByteArrayOutputStream()
        val id = (System.nanoTime() and 0x7fff).toInt()
        out.write(id shr 8)
        out.write(id and 0xff)
        out.write(0x01); out.write(0x00) // flags: recursion desired
        out.write(0); out.write(1)       // QDCOUNT = 1
        repeat(6) { out.write(0) }       // ANCOUNT, NSCOUNT, ARCOUNT
        name.split(".").forEach {
            out.write(it.length)
            out.write(it.toByteArray())
        }
        out.write(0)
        out.write(0); out.write(1)       // QTYPE A
        out.write(0); out.write(1)       // QCLASS IN
        return out.toByteArray()
    }

    /** Raw UDP DNS query to [server]; returns round-trip ms or -1. */
    private suspend fun dnsQuery(server: String, name: String = "example.com"): Long =
        withContext(Dispatchers.IO) {
            try {
                DatagramSocket().use { s ->
                    s.soTimeout = 2000
                    val q = buildQuery(name)
                    val addr = InetAddress.getByName(server)
                    val t0 = System.nanoTime()
                    s.send(DatagramPacket(q, q.size, addr, 53))
                    val buf = ByteArray(512)
                    s.receive(DatagramPacket(buf, buf.size))
                    (System.nanoTime() - t0) / 1_000_000
                }
            } catch (e: Exception) {
                -1L
            }
        }

    private suspend fun bench(server: String): Long {
        var best = -1L
        repeat(3) {
            val t = dnsQuery(server)
            if (t >= 0 && (best < 0 || t < best)) best = t
        }
        return best
    }

    suspend fun dnsBench(extra: List<Pair<String, String>>): List<DnsResult> = coroutineScope {
        val servers = listOf(
            "Cloudflare" to "1.1.1.1",
            "Google" to "8.8.8.8",
            "Quad9" to "9.9.9.9"
        ) + extra
        servers.map { (label, ip) -> async { DnsResult(label, ip, bench(ip)) } }
            .awaitAll()
            .sortedBy { if (it.ms < 0) Long.MAX_VALUE else it.ms }
    }
}
