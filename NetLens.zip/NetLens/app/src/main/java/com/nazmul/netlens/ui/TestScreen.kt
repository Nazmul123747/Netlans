package com.nazmul.netlens.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nazmul.netlens.AppVm
import com.nazmul.netlens.fmt1
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TestScreen(vm: AppVm) {
    LaunchedEffect(Unit) { vm.loadPublicInfo() }
    val df = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("NetLens", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SectionCard {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                SpeedGauge(vm.live, vm.phase)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("Download", fmt1(vm.down))
                Stat("Upload", fmt1(vm.up))
                Stat("Ping ms", fmt1(vm.ping))
                Stat("Jitter ms", fmt1(vm.jitter))
            }
            Button(
                onClick = { if (vm.running) vm.stopSpeedTest() else vm.startSpeedTest() },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (vm.running) "Stop" else "Start speed test") }
        }

        val p = vm.pubInfo
        if (p != null) {
            SectionCard("Your connection") {
                KeyValue("Public IP", p.ip)
                KeyValue("ISP", p.isp.ifBlank { "-" })
                KeyValue("Network", p.org.ifBlank { "-" })
                KeyValue("ASN", p.asn)
                if (p.place.isNotBlank()) KeyValue("Location", p.place)
            }
        }

        SectionCard("Network health check") {
            OutlinedButton(
                onClick = { vm.runHealth() },
                enabled = !vm.healthRunning,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (vm.healthRunning) "Checking…" else "Run health check") }
            vm.health.forEach { h ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    LevelDot(h.level)
                    Spacer(Modifier.width(10.dp))
                    Text(h.label, Modifier.weight(1f))
                    Text(h.value, fontWeight = FontWeight.Medium)
                }
            }
        }

        SectionCard("History") {
            if (vm.history.isEmpty()) {
                Text("No tests yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                vm.history.take(10).forEach { r ->
                    KeyValue(
                        df.format(Date(r.time)),
                        "↓ ${fmt1(r.down)}  ↑ ${fmt1(r.up)}  ${fmt1(r.ping)} ms"
                    )
                }
                TextButton(onClick = { vm.clearHistory() }) { Text("Clear history") }
            }
        }
    }
}
