package com.nazmul.netlens.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nazmul.netlens.AppVm

@Composable
fun ToolsScreen(vm: AppVm) {
    var host by rememberSaveable { mutableStateOf("google.com") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Network tools", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = host,
            onValueChange = { host = it.trim() },
            label = { Text("Host name or IP") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.runPing(host) }, enabled = !vm.toolBusy, modifier = Modifier.weight(1f)) {
                Text("Ping")
            }
            Button(onClick = { vm.runTraceroute(host) }, enabled = !vm.toolBusy, modifier = Modifier.weight(1f)) {
                Text("Trace")
            }
            Button(onClick = { vm.runDns(host) }, enabled = !vm.toolBusy, modifier = Modifier.weight(1f)) {
                Text("DNS")
            }
        }

        SectionCard("Output") {
            Text(
                if (vm.toolBusy && vm.toolOut.isEmpty()) "Working…"
                else vm.toolOut.ifEmpty { "Run a tool to see results." },
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )
        }

        SectionCard("DNS speed benchmark") {
            Text(
                "Compares how fast popular DNS servers answer from your connection, " +
                    "including the DNS your network currently uses.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(
                onClick = { vm.runDnsBench() },
                enabled = !vm.dnsBusy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (vm.dnsBusy) "Testing…" else "Run benchmark") }
            vm.dnsResults.forEachIndexed { i, r ->
                KeyValue(
                    "${r.label} (${r.server})",
                    if (r.ms < 0) "no reply" else "${r.ms} ms" + if (i == 0) "  ★ fastest" else ""
                )
            }
        }
    }
}
