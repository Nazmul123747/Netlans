package com.nazmul.netlens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nazmul.netlens.ui.IspScreen
import com.nazmul.netlens.ui.NetLensTheme
import com.nazmul.netlens.ui.TestScreen
import com.nazmul.netlens.ui.ToolsScreen
import com.nazmul.netlens.ui.UsageScreen
import com.nazmul.netlens.ui.WifiScreen
import org.osmdroid.config.Configuration
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osm")
            osmdroidTileCache = File(cacheDir, "osm/tiles")
        }
        enableEdgeToEdge()
        setContent {
            NetLensTheme {
                NetLensApp()
            }
        }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@Composable
fun NetLensApp(vm: AppVm = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf(
        Tab("Test", Icons.Default.Home),
        Tab("Wi-Fi", Icons.Default.Info),
        Tab("Tools", Icons.Default.Search),
        Tab("ISPs", Icons.Default.Place),
        Tab("Usage", Icons.AutoMirrored.Filled.List)
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> TestScreen(vm)
                1 -> WifiScreen(vm)
                2 -> ToolsScreen(vm)
                3 -> IspScreen(vm)
                else -> UsageScreen(vm)
            }
        }
    }
}
