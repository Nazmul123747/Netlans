package com.nazmul.netlens.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SpeedResult(
    val time: Long,
    val down: Double,
    val up: Double,
    val ping: Double,
    val jitter: Double,
    val isp: String
)

data class Pkg(val name: String, val mbps: Int, val price: Int)

data class Isp(
    val id: String,
    val name: String,
    val area: String,
    val lat: Double,
    val lng: Double,
    val phone: String,
    val packages: List<Pkg>,
    val rating: Float,
    val notes: String
)

/** Tiny local store (SharedPreferences + JSON). No data leaves the device. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("netlens", Context.MODE_PRIVATE)

    fun history(): List<SpeedResult> = try {
        val arr = JSONArray(sp.getString("history", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SpeedResult(
                o.getLong("t"), o.getDouble("d"), o.getDouble("u"),
                o.getDouble("p"), o.getDouble("j"), o.optString("isp")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun addHistory(r: SpeedResult) {
        val list = (listOf(r) + history()).take(50)
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("t", it.time).put("d", it.down).put("u", it.up)
                    .put("p", it.ping).put("j", it.jitter).put("isp", it.isp)
            )
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    fun isps(): List<Isp> = try {
        val arr = JSONArray(sp.getString("isps", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val pk = o.optJSONArray("pk") ?: JSONArray()
            Isp(
                id = o.getString("id"),
                name = o.getString("name"),
                area = o.optString("area"),
                lat = o.getDouble("lat"),
                lng = o.getDouble("lng"),
                phone = o.optString("phone"),
                packages = (0 until pk.length()).map { k ->
                    val p = pk.getJSONObject(k)
                    Pkg(p.getString("n"), p.getInt("m"), p.getInt("p"))
                },
                rating = o.optDouble("rating", 0.0).toFloat(),
                notes = o.optString("notes")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun writeIsps(list: List<Isp>) {
        val arr = JSONArray()
        list.forEach { isp ->
            val pk = JSONArray()
            isp.packages.forEach { pk.put(JSONObject().put("n", it.name).put("m", it.mbps).put("p", it.price)) }
            arr.put(
                JSONObject().put("id", isp.id).put("name", isp.name).put("area", isp.area)
                    .put("lat", isp.lat).put("lng", isp.lng).put("phone", isp.phone)
                    .put("pk", pk).put("rating", isp.rating.toDouble()).put("notes", isp.notes)
            )
        }
        sp.edit().putString("isps", arr.toString()).apply()
    }

    fun saveIsp(isp: Isp) {
        val cur = isps()
        val idx = cur.indexOfFirst { it.id == isp.id }
        writeIsps(if (idx >= 0) cur.toMutableList().also { it[idx] = isp } else cur + isp)
    }

    fun deleteIsp(id: String) {
        writeIsps(isps().filter { it.id != id })
    }
}
