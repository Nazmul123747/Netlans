package com.nazmul.netlens.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class PublicInfo(
    val ip: String,
    val isp: String,
    val org: String,
    val asn: String,
    val place: String
)

object IspLookup {
    /** Looks up the public IP, ISP and ASN of the current connection (ipwho.is, no API key). */
    suspend fun lookup(): PublicInfo? = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://ipwho.is/").openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            if (!j.optBoolean("success", true)) return@withContext null
            val conn = j.optJSONObject("connection")
            val asn = conn?.optInt("asn", 0) ?: 0
            PublicInfo(
                ip = j.optString("ip"),
                isp = conn?.optString("isp").orEmpty(),
                org = conn?.optString("org").orEmpty(),
                asn = if (asn > 0) "AS$asn" else "-",
                place = listOf(j.optString("city"), j.optString("country"))
                    .filter { it.isNotBlank() }.joinToString(", ")
            )
        } catch (e: Exception) {
            null
        }
    }
}
