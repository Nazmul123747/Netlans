package com.nazmul.netlens.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.nazmul.netlens.AppVm
import com.nazmul.netlens.data.Isp
import com.nazmul.netlens.data.Pkg
import com.nazmul.netlens.distKm
import com.nazmul.netlens.fmt1
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.util.UUID

@Composable
fun IspScreen(vm: AppVm) {
    val ctx = LocalContext.current
    var showMap by rememberSaveable { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Isp?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) vm.locate()
    }
    LaunchedEffect(Unit) { if (hasFineLocation(ctx)) vm.locate() }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(selected = showMap, onClick = { showMap = true }, label = { Text("Map") })
            FilterChip(selected = !showMap, onClick = { showMap = false }, label = { Text("List") })
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                launcher.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
            }) { Text("My location") }
            Button(onClick = { editing = null; showDialog = true }) { Text("Add ISP") }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (showMap) {
                OsmMap(vm.isps, vm.myLoc)
            } else {
                IspList(vm, onEdit = { editing = it; showDialog = true })
            }
        }
    }

    if (showDialog) {
        IspDialog(
            initial = editing,
            defaultLoc = vm.myLoc,
            onDismiss = { showDialog = false },
            onSave = { vm.saveIsp(it); showDialog = false }
        )
    }
}

@Composable
private fun OsmMap(isps: List<Isp>, me: Pair<Double, Double>?) {
    val ctx = LocalContext.current
    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(23.8103, 90.4125)) // Dhaka until we know better
        }
    }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose {
            lifecycle.removeObserver(obs)
            mapView.onDetach()
        }
    }
    LaunchedEffect(me) {
        me?.let { mapView.controller.setCenter(GeoPoint(it.first, it.second)) }
    }
    AndroidView(
        factory = { mapView },
        modifier = Modifier.fillMaxSize(),
        update = { mv ->
            mv.overlays.clear()
            isps.forEach { isp ->
                val m = Marker(mv)
                m.position = GeoPoint(isp.lat, isp.lng)
                m.title = isp.name
                m.snippet = listOf(isp.area, isp.phone).filter { it.isNotBlank() }.joinToString(" • ")
                m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                mv.overlays.add(m)
            }
            if (me != null) {
                val m = Marker(mv)
                m.position = GeoPoint(me.first, me.second)
                m.title = "You are here"
                m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                mv.overlays.add(m)
            }
            mv.invalidate()
        }
    )
}

@Composable
private fun IspList(vm: AppVm, onEdit: (Isp) -> Unit) {
    val ctx = LocalContext.current
    val sorted = remember(vm.isps, vm.myLoc) {
        val me = vm.myLoc
        if (me != null) vm.isps.sortedBy { distKm(me.first, me.second, it.lat, it.lng) } else vm.isps
    }
    if (sorted.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(
                "No ISPs saved yet.\nTap “Add ISP” to save a provider with its location, " +
                    "packages and phone number.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(sorted, key = { it.id }) { isp ->
            SectionCard(isp.name) {
                val me = vm.myLoc
                val sub = buildList {
                    if (isp.area.isNotBlank()) add(isp.area)
                    if (me != null) add("${fmt1(distKm(me.first, me.second, isp.lat, isp.lng))} km away")
                    if (isp.rating > 0f) add("★ ${fmt1(isp.rating.toDouble())}")
                }.joinToString(" • ")
                if (sub.isNotBlank()) Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant)
                isp.packages.forEach { KeyValue(it.name, "${it.mbps} Mbps • ৳${it.price}") }
                if (isp.notes.isNotBlank()) Text(isp.notes)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (isp.phone.isNotBlank()) {
                        TextButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${isp.phone}")))
                        }) { Text("Call") }
                    }
                    TextButton(onClick = { onEdit(isp) }) { Text("Edit") }
                    TextButton(onClick = { vm.deleteIsp(isp.id) }) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
private fun IspDialog(
    initial: Isp?,
    defaultLoc: Pair<Double, Double>?,
    onDismiss: () -> Unit,
    onSave: (Isp) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var area by remember { mutableStateOf(initial?.area ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var latS by remember { mutableStateOf(initial?.lat?.toString() ?: defaultLoc?.first?.toString() ?: "") }
    var lngS by remember { mutableStateOf(initial?.lng?.toString() ?: defaultLoc?.second?.toString() ?: "") }
    var ratingS by remember { mutableStateOf(initial?.rating?.takeIf { it > 0f }?.toString() ?: "") }
    var pkgs by remember {
        mutableStateOf(initial?.packages?.joinToString("\n") { "${it.name},${it.mbps},${it.price}" } ?: "")
    }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add ISP" else "Edit ISP") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(area, { area = it }, label = { Text("Area / coverage") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(latS, { latS = it }, label = { Text("Latitude") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(lngS, { lngS = it }, label = { Text("Longitude") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(ratingS, { ratingS = it }, label = { Text("Your rating (0–5)") }, singleLine = true)
                OutlinedTextField(
                    pkgs, { pkgs = it },
                    label = { Text("Packages: name,Mbps,price (one per line)") },
                    minLines = 3
                )
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, minLines = 2)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val lat = latS.trim().toDoubleOrNull()
                val lng = lngS.trim().toDoubleOrNull()
                if (name.isBlank()) {
                    error = "Name is required"
                } else if (lat == null || lng == null || lat !in -90.0..90.0 || lng !in -180.0..180.0) {
                    error = "Enter a valid latitude and longitude"
                } else {
                    val list = pkgs.lines().mapNotNull { line ->
                        val p = line.split(",")
                        val m = p.getOrNull(1)?.trim()?.toIntOrNull()
                        val pr = p.getOrNull(2)?.trim()?.toIntOrNull()
                        if (p.size >= 3 && p[0].isNotBlank() && m != null && pr != null) Pkg(p[0].trim(), m, pr) else null
                    }
                    onSave(
                        Isp(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            name = name.trim(),
                            area = area.trim(),
                            lat = lat,
                            lng = lng,
                            phone = phone.trim(),
                            packages = list,
                            rating = (ratingS.trim().toFloatOrNull() ?: 0f).coerceIn(0f, 5f),
                            notes = notes.trim()
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
