package com.nazmul.netlens.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nazmul.netlens.AppVm
import com.nazmul.netlens.fmt1
import com.nazmul.netlens.net.WifiTools

@Composable
fun WifiScreen(vm: AppVm) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasFineLocation(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        granted = res[Manifest.permission.ACCESS_FINE_LOCATION] == true
    }
    LaunchedEffect(granted) { if (granted) vm.scanWifi() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Wi-Fi analyzer", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        if (!granted) {
            SectionCard("Location permission needed") {
                Text(
                    "Android only lets apps list nearby Wi-Fi networks and read the connected " +
                        "network name when location permission is granted. NetLens never uploads your location."
                )
                Button(onClick = {
                    launcher.launch(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    )
                }) { Text("Grant permission") }
            }
            return@Column
        }

        val w = vm.wifiInfo
        SectionCard("Connected network") {
            if (w == null) {
                Text("Not connected to Wi-Fi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                KeyValue("SSID", w.ssid)
                KeyValue("BSSID", w.bssid)
                KeyValue("Signal", "${w.rssi} dBm")
                KeyValue("Band / channel", "${w.band} • ch ${w.channel}")
                KeyValue("Link speed", "${w.linkMbps} Mbps")
                KeyValue("Router distance (very rough)", "~${fmt1(w.distanceM)} m")
            }
        }

        Button(onClick = { vm.scanWifi() }, enabled = !vm.scanning, modifier = Modifier.fillMaxWidth()) {
            Text(if (vm.scanning) "Scanning…" else "Scan nearby networks")
        }

        if (vm.aps.isEmpty()) {
            if (!vm.scanning) {
                Text(
                    "No networks found. Make sure Wi-Fi and Location services are turned on. " +
                        "Android limits how often apps can scan, so try again in a minute.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            return@Column
        }

        val cong = remember(vm.aps) { WifiTools.congestion24(vm.aps) }
        val best = remember(cong) { listOf(1, 6, 11).minByOrNull { cong[it - 1] } ?: 1 }
        SectionCard("2.4 GHz channel congestion") {
            BarChart(cong, (1..13).map { it.toString() }, highlight = setOf(best - 1))
            Text("Least crowded of channels 1 / 6 / 11: channel $best")
        }

        val five = remember(vm.aps) {
            vm.aps.filter { it.band != "2.4 GHz" }.groupingBy { it.channel }.eachCount().toSortedMap()
        }
        if (five.isNotEmpty()) {
            SectionCard("5 / 6 GHz channels in use") {
                Text(five.entries.joinToString("   ") { "ch ${it.key}: ${it.value}" })
            }
        }

        SectionCard("Nearby networks (${vm.aps.size})") {
            vm.aps.forEachIndexed { i, ap ->
                if (i > 0) HorizontalDivider()
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(ap.ssid.ifBlank { "(hidden)" }, fontWeight = FontWeight.Medium)
                        Text("${ap.rssi} dBm")
                    }
                    LinearProgressIndicator(
                        progress = { ((ap.rssi + 100) / 60f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "ch ${ap.channel} • ${ap.band} • ${ap.security}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
