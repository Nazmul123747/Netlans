package com.nazmul.netlens.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nazmul.netlens.AppVm
import com.nazmul.netlens.fmtBytes

@Composable
fun UsageScreen(vm: AppVm) {
    val ctx = LocalContext.current
    OnResume { vm.refreshUsage() }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Data usage", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        if (!vm.usageAccess) {
            SectionCard("Permission needed") {
                Text(
                    "To show how much data each app has used, allow “Usage access” for NetLens " +
                        "in Android settings. This stays on your device."
                )
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) {
                    Text("Open settings")
                }
            }
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1 to "24 h", 7 to "7 days", 30 to "30 days").forEach { (d, l) ->
                FilterChip(selected = vm.usageDays == d, onClick = { vm.setUsageDays(d) }, label = { Text(l) })
            }
        }
        if (vm.usageLoading) LinearProgressIndicator(Modifier.fillMaxWidth())

        val total = vm.usage.sumOf { it.total }
        val top = (vm.usage.firstOrNull()?.total ?: 1L).coerceAtLeast(1L)
        Text("Total: ${fmtBytes(total)}", style = MaterialTheme.typography.titleMedium)

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vm.usage, key = { it.label }) { u ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(u.label, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        Text(fmtBytes(u.total))
                    }
                    LinearProgressIndicator(
                        progress = { (u.total.toFloat() / top).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Wi-Fi ${fmtBytes(u.wifi)}  •  Mobile ${fmtBytes(u.mobile)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
