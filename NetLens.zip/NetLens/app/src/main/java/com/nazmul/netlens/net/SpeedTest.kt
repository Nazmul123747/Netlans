package com.nazmul.netlens.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Random
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

/** Speed test against Cloudflare's public speed endpoints (multi-connection, time-boxed). */
object SpeedTest {
    private const val DOWN = "https://speed.cloudflare.com/__down?bytes="
    private const val UP = "https://speed.cloudflare.com/__up"

    /** Returns (average latency ms, jitter ms). */
    suspend fun latency(samples: Int = 10): Pair<Double, Double> = withContext(Dispatchers.IO) {
        val times = ArrayList<Double>()
        for (i in 0..samples) {
            val t0 = System.nanoTime()
            try {
                val c = URL(DOWN + "0").openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                c.inputStream.use { it.readBytes() }
                if (i > 0) times.add((System.nanoTime() - t0) / 1e6) // first request warms up TLS
            } catch (e: Exception) {
                // ignore failed sample
            }
        }
        if (times.isEmpty()) return@withContext Pair(0.0, 0.0)
        var diff = 0.0
        for (k in 1 until times.size) diff += abs(times[k] - times[k - 1])
        val jitter = if (times.size > 1) diff / (times.size - 1) else 0.0
        Pair(times.average(), jitter)
    }

    /** Returns Mbps. [onProgress] is called ~4x/second with the live rate. */
    suspend fun download(
        durationMs: Long = 8000,
        threads: Int = 4,
        onProgress: (Double) -> Unit
    ): Double = coroutineScope {
        val bytes = AtomicLong(0)
        val start = System.nanoTime()
        val end = start + durationMs * 1_000_000
        fun mbps(): Double {
            val s = (System.nanoTime() - start) / 1e9
            return if (s <= 0) 0.0 else bytes.get() * 8 / s / 1e6
        }
        val workers = (1..threads).map {
            async(Dispatchers.IO) {
                val buf = ByteArray(64 * 1024)
                while (System.nanoTime() < end && isActive) {
                    try {
                        val c = URL(DOWN + "25000000").openConnection() as HttpURLConnection
                        c.connectTimeout = 5000
                        c.readTimeout = 5000
                        c.inputStream.use { ins ->
                            while (System.nanoTime() < end && isActive) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                bytes.addAndGet(n.toLong())
                            }
                        }
                    } catch (e: Exception) {
                        break
                    }
                }
            }
        }
        val ticker = launch {
            while (isActive) {
                delay(250)
                onProgress(mbps())
            }
        }
        workers.awaitAll()
        ticker.cancel()
        mbps()
    }

    /** Returns Mbps. */
    suspend fun upload(
        durationMs: Long = 6000,
        threads: Int = 3,
        onProgress: (Double) -> Unit
    ): Double = coroutineScope {
        val bytes = AtomicLong(0)
        val payload = ByteArray(1_000_000).also { Random().nextBytes(it) }
        val start = System.nanoTime()
        val end = start + durationMs * 1_000_000
        fun mbps(): Double {
            val s = (System.nanoTime() - start) / 1e9
            return if (s <= 0) 0.0 else bytes.get() * 8 / s / 1e6
        }
        val workers = (1..threads).map {
            async(Dispatchers.IO) {
                while (System.nanoTime() < end && isActive) {
                    try {
                        val c = URL(UP).openConnection() as HttpURLConnection
                        c.requestMethod = "POST"
                        c.doOutput = true
                        c.connectTimeout = 5000
                        c.readTimeout = 8000
                        c.setFixedLengthStreamingMode(payload.size)
                        c.outputStream.use { os ->
                            var off = 0
                            while (off < payload.size) {
                                val n = minOf(32 * 1024, payload.size - off)
                                os.write(payload, off, n)
                                off += n
                                bytes.addAndGet(n.toLong())
                            }
                        }
                        c.inputStream.use { it.readBytes() }
                    } catch (e: Exception) {
                        break
                    }
                }
            }
        }
        val ticker = launch {
            while (isActive) {
                delay(250)
                onProgress(mbps())
            }
        }
        workers.awaitAll()
        ticker.cancel()
        mbps()
    }
}
