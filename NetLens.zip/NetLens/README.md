# NetLens

A network toolkit for Android (Kotlin + Jetpack Compose). Original app, own name and design.

## Features

| Tab | What it does |
|---|---|
| **Test** | Speed test (download, upload, ping, jitter via Cloudflare), public IP / ISP / ASN lookup, network health check (gateway latency, DNS time, Wi-Fi signal, internet reachability), test history |
| **Wi-Fi** | Connected network details, nearby network scan, 2.4 GHz channel congestion chart with best-channel suggestion, 5/6 GHz channel usage, rough router distance |
| **Tools** | Ping, traceroute, DNS lookup, DNS speed benchmark (Cloudflare, Google, Quad9, your network's DNS) |
| **ISPs** | Your own ISP directory on an OpenStreetMap map and list: location, phone, packages/prices, rating, notes; sorted by distance; tap to call |
| **Usage** | Per-app Wi-Fi / mobile data usage for 24 h, 7 days, 30 days |

## Build

1. Install Android Studio (Koala or newer).
2. `File > Open` and choose this folder. Let Gradle sync (needs internet).
3. Plug in a phone (USB debugging on) or start an emulator, then press Run.
4. APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

Android Studio downloads Gradle 8.9 itself from `gradle/wrapper/gradle-wrapper.properties`.
For terminal builds, run `gradle wrapper` once (with Gradle installed), then `./gradlew assembleDebug`
(APK in `app/build/outputs/apk/debug/`).

## Notes

- Requires Android 8.0 (API 26) or newer.
- **Wi-Fi tab** needs Location permission and Location services turned on (Android rule for Wi-Fi scans).
- **Usage tab** needs "Usage access" granted in system settings (the app opens it for you).
- **Traceroute** uses the system `ping -t`; per-hop time is approximate.
- **ISP directory** is local: you enter the providers. No third-party ISP data is bundled.
- Map tiles come from OpenStreetMap; for heavy or public use, follow their tile usage policy or switch to a paid tile provider.
- `QUERY_ALL_PACKAGES` is used to show app names in Usage. Google Play restricts this permission, so remove it (apps will show as package names) before a Play Store release.

## Ideas for next steps

- Live per-app traffic monitor using `VpnService` (local only).
- Sync the ISP directory to a backend so customers/other users can see and review.
- Scheduled background speed tests with notifications.
